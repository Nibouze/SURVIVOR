import pygame
import random

# Initialize Pygame
pygame.init()

# Window settings
WIN_WIDTH = 1920
WIN_HEIGHT = 1080
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Top-Down Exploration Game")

# World settings
WORLD_WIDTH = 5000
WORLD_HEIGHT = 5000

# Colors
BLACK = (0, 0, 0)

# Load background image
background_image = pygame.image.load('forest.png').convert()
background_width, background_height = background_image.get_size()

# Load player image
player_image = pygame.image.load('pedro.png').convert_alpha()  # Convert_alpha() to handle transparency
player_size = player_image.get_rect().size  # Get the size of the player image
player_speed = 10
player_rect = player_image.get_rect(center=(WORLD_WIDTH // 2, WORLD_HEIGHT // 2))

# Camera settings
camera_pos = [0, 0]

# Obstacles
obstacle_size = 40
obstacles = []
for _ in range(20):
    x = random.randint(0, WORLD_WIDTH - obstacle_size)
    y = random.randint(0, WORLD_HEIGHT - obstacle_size)
    obstacles.append(pygame.Rect(x, y, obstacle_size, obstacle_size))

# Game loop
run = True
clock = pygame.time.Clock()

def move_player(keys, player_rect):
    new_rect = player_rect.copy()  # We create a copy to test new positions
    
    # Move horizontally first (left and right)
    if keys[pygame.K_LEFT]:
        new_rect.x -= player_speed
    if keys[pygame.K_RIGHT]:
        new_rect.x += player_speed
    
    # Check for horizontal collisions and world boundaries
    if not check_collision(new_rect) and within_world_bounds(new_rect):
        player_rect.x = new_rect.x  # If no collision, apply the movement
    
    # Move vertically (up and down)
    new_rect = player_rect.copy()  # Reset to current position
    if keys[pygame.K_UP]:
        new_rect.y -= player_speed
    if keys[pygame.K_DOWN]:
        new_rect.y += player_speed
    
    # Check for vertical collisions and world boundaries
    if not check_collision(new_rect) and within_world_bounds(new_rect):
        player_rect.y = new_rect.y  # If no collision, apply the movement

def within_world_bounds(rect):
    """Ensure the player stays within the world boundaries."""
    return (0 <= rect.x <= WORLD_WIDTH - player_size[0]) and (0 <= rect.y <= WORLD_HEIGHT - player_size[1])

def check_collision(rect):
    for obstacle in obstacles:
        if rect.colliderect(obstacle):  # Check if the player's rect intersects any obstacle
            return True
    return False

def update_camera(camera_pos, player_rect):
    # Center camera on player, but clamp to world boundaries
    camera_pos[0] = min(max(player_rect.x + player_size[0] // 2 - WIN_WIDTH // 2, 0), WORLD_WIDTH - WIN_WIDTH)
    camera_pos[1] = min(max(player_rect.y + player_size[1] // 2 - WIN_HEIGHT // 2, 0), WORLD_HEIGHT - WIN_HEIGHT)

def draw_world(win, camera_pos, player_rect):
    # Draw the background image repeatedly to cover the world
    for x in range(0, WORLD_WIDTH, background_width):
        for y in range(0, WORLD_HEIGHT, background_height):
            win.blit(background_image, (x - camera_pos[0], y - camera_pos[1]))
    
    # Draw obstacles
    for obstacle in obstacles:
        pygame.draw.rect(win, BLACK, pygame.Rect(
            obstacle.x - camera_pos[0], obstacle.y - camera_pos[1], obstacle.width, obstacle.height))
    
    # Draw the player image
    win.blit(player_image, (player_rect.x - camera_pos[0], player_rect.y - camera_pos[1]))

# Main game loop
while run:
    clock.tick(60)  # 60 frames per second
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Handle movement
    keys = pygame.key.get_pressed()
    move_player(keys, player_rect)
    update_camera(camera_pos, player_rect)

    # Draw everything
    draw_world(win, camera_pos, player_rect)

    # Update the display
    pygame.display.flip()

# Quit the game
pygame.quit()
