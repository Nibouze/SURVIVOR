import pygame

# Initialisation de Pygame
pygame.init()

# Paramètres d'affichage
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Animation Sprite")

# Charger les spritesheets
spritesheets = {
    "attaque3": pygame.image.load("sprites/player/attaque3.png"),
    "waiting": pygame.image.load("sprites/player/waiting.png")
}

# Infos sur les animations
animations = {
    "attaque3": {"cols": 8, "rows": 4, "size": spritesheets["attaque3"].get_size()},
    "waiting": {"cols": 2, "rows": 4, "size": spritesheets["waiting"].get_size()}  # Correction des tailles réelles
}

# Découpe des spritesheets
def load_frames(sheet, cols, rows, width, height):
    frames = []
    frame_width = width // cols
    frame_height = height // rows
    for row in range(rows):
        row_frames = []
        for col in range(cols):
            if col * frame_width + frame_width <= width and row * frame_height + frame_height <= height :
                frame = sheet.subsurface(pygame.Rect(col * frame_width, row * frame_height, frame_width, frame_height))
                frame = pygame.transform.scale(frame, (frame_width * 2, frame_height * 2))  # Agrandir à 200%
                row_frames.append(frame)
        if row_frames:
            frames.append(row_frames)
    return frames

frames = {name: load_frames(spritesheets[name], data["cols"], data["rows"], *data["size"]) for name, data in animations.items()}

# Gestion des animations
current_animation = "waiting"
frame_index = 0
row_index = 0
clock = pygame.time.Clock()
attack_playing = False
attack_queue = None

# Déplacements
directions = {pygame.K_UP: 0, pygame.K_LEFT : 1, pygame.K_DOWN: 2, pygame.K_RIGHT : 3}
position = [WIDTH // 2, HEIGHT // 2]
speed = 5



def lancer_attaque():
    global attack_playing, attack_queue, frame_index, current_animation, row_index

    attack_queue = "attaque3"
    attack_playing = True
    frame_index = 0
    row_index = 0  # Initialisation correcte de row_index

    while attack_playing:
        screen.fill((0, 0, 0))  # Fond noir

        # Gestion de l'animation
        current_animation = attack_queue
        if frame_index >= len(frames[current_animation][row_index]) - 1:
            attack_playing = False
            current_animation = "waiting"
            frame_index = 0  # Réinitialiser l'animation après l'attaque
        else:
            frame_index += 1

        # Afficher la frame actuelle
        sprite_list = frames[current_animation]
        row_index = min(row_index, len(sprite_list) - 1)  # Évite un index hors limites
        frame = sprite_list[row_index][frame_index]
        frame_rect = frame.get_rect()
        frame_rect.center = position  # Mise à jour de la position
        screen.blit(frame, frame_rect.topleft)

        pygame.display.flip()
        pygame.time.delay(100)  # Vitesse de l'animation
