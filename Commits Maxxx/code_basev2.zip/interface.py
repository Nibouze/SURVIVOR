import pygame
import sys
import os
import subprocess
import jeu



# Couleurs et dimensions
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)
ROUGE = (255, 0, 0)
LARGEUR, HAUTEUR = 1920, 1080

# Chargement de l'image de fond
img = pygame.image.load('menu.png')

def zoom_fade(screen, img, cible):
    clock = pygame.time.Clock()
    zoom = 1
    fade_alpha = 0
    fade_surface = pygame.Surface((LARGEUR, HAUTEUR))
    fade_surface.fill(NOIR)
    
    volume_actuel = pygame.mixer.music.get_volume()
    
    while zoom < 5.5:  # Zoom progressif
        clock.tick(30)
        screen.fill(NOIR)
        
        # Calcul de la nouvelle taille
        taille = int(LARGEUR * zoom), int(HAUTEUR * zoom)
        zoomed_img = pygame.transform.scale(img, taille)
        
        # Décalage pour garder la cible en place
        x = -((cible[0] + 420) * (zoom - 1))
        y = -((cible[1] - 50) * (zoom - 1))
        
        screen.blit(zoomed_img, (x, y))
        pygame.display.flip()
        zoom += 0.15
        
        # Diminuer progressivement le volume de la musique
        if volume_actuel > 0:
            volume_actuel = max(0, volume_actuel - 0.03)
            pygame.mixer.music.set_volume(volume_actuel)
    
    # Effet de fade-out
    while fade_alpha < 255:
        clock.tick(30)
        fade_surface.set_alpha(fade_alpha)
        screen.blit(fade_surface, (0, 0))
        pygame.display.flip()
        fade_alpha += 5
        
        # Continuer à réduire le volume de la musique
        if volume_actuel > 0:
            volume_actuel = max(0, volume_actuel - 0.03)
            pygame.mixer.music.set_volume(volume_actuel)
        pygame.mixer.music.stop()  # Arrête la musique après le fade-out



class Menu:
    def __init__(self, screen, options, font, font_color, couleur):
        self.screen = screen
        self.options = options
        self.font = font
        self.font_color = font_color
        self.couleur = couleur
        self.positions = {
            "JOUER": (350, 180),
            "EXIT": (LARGEUR - 300, 180),
            "OPTIONS": (370, HAUTEUR - 200),
            "RETOUR": ( 350, HAUTEUR - 200)
        }
    
    def draw(self):
        souris_pos = pygame.mouse.get_pos()
        for option in self.options:
            text = self.font.render(option, True, self.font_color)
            text_rect = text.get_rect(center=self.positions[option])
            if text_rect.collidepoint(souris_pos):
                zoomed_font = pygame.font.Font("VINERITC.ttf", 80)
                text = zoomed_font.render(option, True, ROUGE)
                text_rect = text.get_rect(center=self.positions[option])
            self.screen.blit(text, text_rect)
    
    def event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            souris_pos = pygame.mouse.get_pos()
            for option in self.options:
                text_rect = pygame.Rect(self.positions[option][0] - 50, self.positions[option][1] - 25, 100, 50)
                if text_rect.collidepoint(souris_pos):
                    return option
        return None

def photo(screen, img):
    screen.blit(pygame.transform.scale(img, (LARGEUR, HAUTEUR)), (0, 0))

def options_menu(screen, img, volume_actuel):
    options = ["RETOUR"]
    font = pygame.font.Font("VINERITC.ttf", 60)
    menu = Menu(screen, options, font, BLANC, NOIR)
    running = True
    while running:
        photo(screen, img)
        afficher_titre_volume(screen)
        bar_volume(screen, volume_actuel)
        menu.draw()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            selected = menu.event(event)
            if selected == "RETOUR":
                return volume_actuel
            if event.type in [pygame.MOUSEBUTTONDOWN, pygame.MOUSEMOTION]:
                if pygame.mouse.get_pressed()[0]:
                    volume_actuel = changement_volume(event.pos, volume_actuel)
                    pygame.mixer.music.set_volume(volume_actuel)
        pygame.display.flip()

def afficher_titre_volume(screen):
    font = pygame.font.Font("VINERITC.ttf", 50)
    text = font.render("VOLUME", True, BLANC)
    text_rect = text.get_rect(center=(LARGEUR // 2, 200))
    screen.blit(text, text_rect)

def bar_volume(screen, volume_actuel):
    largeur_bar, hauteur_bar = 400, 20
    bar_x, bar_y = (LARGEUR - largeur_bar) // 2, 320
    pygame.draw.rect(screen, NOIR, (bar_x, bar_y, largeur_bar, hauteur_bar))
    pygame.draw.rect(screen, ROUGE, (bar_x, bar_y, int(largeur_bar * volume_actuel), hauteur_bar))
    pygame.draw.circle(screen, BLANC, (bar_x + int(largeur_bar * volume_actuel), bar_y + hauteur_bar // 2), 10)
    font = pygame.font.Font("VINERITC.ttf", 40)
    screen.blit(font.render(f"{int(volume_actuel * 100)}%", True, BLANC), (LARGEUR // 2 - 20, bar_y - 50))

def changement_volume(souris_pos, volume_actuel):
    largeur_bar, bar_x = 400, (LARGEUR - 400) // 2
    if bar_x <= souris_pos[0] <= bar_x + largeur_bar:
        return min(max((souris_pos[0] - bar_x) / largeur_bar, 0.0), 1.0)
    return volume_actuel

def play_music():
    pygame.mixer.music.stop()  # Arrête la musique en cours (si elle existe)
    pygame.mixer.music.load('menu.mp3')
    pygame.mixer.music.set_volume(2.0)  # Volume à 200%
    pygame.mixer.music.play(-1, 0.0)  # Relance la musique en boucle


def main():
    pygame.init()
    pygame.mixer.init()
    play_music()
    screen = pygame.display.set_mode((LARGEUR, HAUTEUR))
    pygame.display.set_caption("Menu Principal")
    font = pygame.font.Font("VINERITC.ttf", 60)
    options = ["JOUER", "OPTIONS", "EXIT"]
    menu = Menu(screen, options, font, BLANC, NOIR)
    volume_actuel = 0.5
    while True:
        photo(screen, img)
        if not pygame.mixer.music.get_busy():
            play_music()
        menu.draw()
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            selected = menu.event(event)
            if selected:
                if selected == "JOUER":
                    zoom_fade(screen, img, menu.positions["JOUER"])
                    return  # Quitte la boucle du menu sans fermer la fenêtre

                elif selected == "OPTIONS":
                    volume_actuel = options_menu(screen, img, volume_actuel)
                elif selected == "EXIT":
                    pygame.quit()
                    sys.exit()

if __name__ == "__main__":
    main()
    jeu.main()
