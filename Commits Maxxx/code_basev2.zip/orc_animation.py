import pygame 

PLAYER_SCALE = 80
speed = 5 


pygame.init()
win = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Survivor")

class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.run_spritesheet = pygame.image.load('sprites/player/orc_run.png')  
        self.walk_spritesheet = pygame.image.load('sprites/player/walk.png') 
        self.attaque_1_spritesheet = pygame.image.load('sprites/player/attaque1.png') 
        self.attaque_2_spritesheet = pygame.image.load('sprites/player/attaque2.png') 
        self.attaque_3_spritesheet = pygame.image.load('sprites/player/attaque3.png') 

        self.frame_width = self.run_spritesheet.get_width() // 8  
        self.frame_height = self.run_spritesheet.get_height() // 4  

        self.scale_factor = PLAYER_SCALE  
        
        self.current_sprite = 0
        self.moving = False
        self.running = False
        self.attacking = False
        self.attack_type = None
        self.direction = "down"
        self.rect = pygame.Rect(pos_x, pos_y, self.frame_width * self.scale_factor, self.frame_height * self.scale_factor)

    def get_frame(self, frame, direction, running, attacking=False):
        directions = {"up": 0, "left": 1, "down": 2, "right": 3}  
        row = directions.get(direction, 2)  
        x = frame * self.frame_width
        y = row * self.frame_height

        if attacking:
            if self.attack_type == 1:
                spritesheet = self.attaque_1_spritesheet
            elif self.attack_type == 2:
                spritesheet = self.attaque_2_spritesheet
            elif self.attack_type == 3:
                spritesheet = self.attaque_3_spritesheet
            else:
                return None  
        else:
            spritesheet = self.run_spritesheet if running else self.walk_spritesheet
        
        frame_image = spritesheet.subsurface(pygame.Rect(x, y, self.frame_width, self.frame_height))
        return pygame.transform.scale(frame_image, (self.frame_width * self.scale_factor, self.frame_height * self.scale_factor))

    def get_attack_frames(self):
        if self.attack_type == 1:
            return 6
        elif self.attack_type == 2:
            return 6
        elif self.attack_type == 3:
            return 8
        return 8  # Valeur par défaut


    def start_moving(self, direction, running):
        if not self.attacking:
            self.moving = True
            self.running = running
            self.direction = direction

    def stop_moving(self):
        if not self.attacking:
            self.moving = False
            self.current_sprite = 0

    def start_attack(self, attack_type):
        self.attacking = True
        self.attack_type = attack_type
        self.current_sprite = 0

    def update(self):
        if self.attacking:
            self.current_sprite += 0.2  
            if self.current_sprite >= self.get_attack_frames():  # On utilise le bon nombre de frames
                self.attacking = False
                self.current_sprite = 0
        elif self.moving:
            self.current_sprite += 0.2  
            if self.current_sprite >= 8:
                self.current_sprite = 0

        # Récupérer l'image actuelle
        new_image = self.get_frame(int(self.current_sprite), self.direction, self.running, self.attacking)
        
        # S'assurer que l'image n'est jamais None
        if new_image:
            self.image = new_image
        else:
            self.image = self.get_frame(0, self.direction, False)  # Remet un sprite de base si erreur




while True : 
    for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            keys = pygame.key.get_pressed()
            if keys[pygame.K_w]:  
                Player.start_moving("up", running=True)
                move_y = -speed
            elif keys[pygame.K_UP]:  
                Player.start_moving("up", running=False)
                move_y = -speed

            if keys[pygame.K_s]:  
                Player.start_moving("down", running=True)
                move_y = speed
            elif keys[pygame.K_DOWN]:  
                Player.start_moving("down", running=False)
                move_y = speed

            if keys[pygame.K_a]:  
                Player.start_moving("left", running=True)
                move_x = -speed
            elif keys[pygame.K_LEFT]:  
                Player.start_moving("left", running=False)
                move_x = -speed

            if keys[pygame.K_d]:  
                Player.start_moving("right", running=True)
                move_x = speed
            elif keys[pygame.K_RIGHT]:  
                Player.start_moving("right", running=False)
                move_x = speed
