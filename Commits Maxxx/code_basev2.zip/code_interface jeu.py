import pygame
import csv
import os
import sys

# === CONSTANTES ===
WIN_WIDTH, WIN_HEIGHT = 1920, 1080
TILE_SIZE = 80
PLAYER_SCALE = 2
PLAYER_SPEED_WALK = 5
PLAYER_SPEED_RUN = 10
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

# === INITIALISATION DE PYGAME ===
pygame.init()
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Survivor")

# === CHARGEMENT DES RESSOURCES ===
background_img = pygame.image.load('donjon.jpg')
music_path = 'musique_donjon.mp3'
font_path = "dungeon.ttf"

# === CHARGEMENT DES IMAGES POUR LA CARTE ===
def load_and_scale_image(path):
    try:
        return pygame.transform.scale(pygame.image.load(path).convert(), (TILE_SIZE, TILE_SIZE))
    except pygame.error as e:
        print(f"Erreur de chargement de l'image {path}: {e}")
        return None
    

#  Dictionnaire pour associer chaque caractère à son image (chiffres remplacés par 0 à 42)
image_map = {
    0 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_left_exterior_corner.png'),
    1 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_right_exterior_corner.png'),
    2 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_left_interior_corner.png'),
    3 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_right_interior_corner.png'),
    4 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/right.png'),
    5 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/bottom.png'),
    6 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_left_exterior_corner.png'),
    7 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_right_exterior_corner.png'),
    8 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_left_interior_corner.png'),
    9 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_right_interior_corner.png'),
    10: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/top.png'),
    11: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/left.png'),
    12: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_left_exterior_corner.png'),
    13: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_right_exterior_corner.png'),
    14: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_left_interior_corner.png'),
    15: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_right_interior_corner.png'),
    16: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/right.png'),
    17: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/bottom.png'),
    18: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_left_exterior_corner.png'),
    19: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_right_exterior_corner.png'),
    20: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_left_interior_corner.png'),
    21: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_right_interior_corner.png'),
    22: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/top.png'),
    23: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/left.png'),
    24: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_left_wall.png'),
    25: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_top_wall.png'),
    26: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_left_corner.png'),
    27: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_right_corner.png'),
    28: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    29: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    30: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_bottom_wall.png'),
    31: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_right_wall.png'),
    32: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_left_corner.png'),
    33: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_right_corner.png'),
    34: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    35: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    36: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/path_bg_color.png'),
    37: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/exterior_background.png'),
    38: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/interior_background.png'),
    40: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_top-left_bottom-right.png'),
    41: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_bottom-left_top-right.png'),

}

# === CHARGEMENT DES DONNÉES DE LA CARTE ===
def load_matrix_from_csv(file_path):
    if not os.path.exists(file_path):
        print(f"Erreur: fichier '{file_path}' non trouvé.")
        return []
    try:
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            return [list(map(int, row)) for row in csv.reader(csvfile)]
    except Exception as e:
        print(f"Erreur de lecture du fichier CSV: {e}")
        return []

matrix_file = 'nul.csv'
lines = load_matrix_from_csv(matrix_file)

if not lines:
    print("Erreur: Matrice vide ou invalide.")
    pygame.quit()
    sys.exit()

rows, cols = len(lines), len(lines[0])
matrix_width, matrix_height = cols * TILE_SIZE, rows * TILE_SIZE

# === SYSTÈME DE CAMERA ===
def can_move_to(tile):
    return tile == 38 or tile == 37

player_x, player_y = matrix_width // 2, matrix_height // 2
player_screen_x, player_screen_y = WIN_WIDTH // 2, WIN_HEIGHT // 2

def move_player(dx, dy):
    global player_x, player_y
    new_x, new_y = player_x + dx, player_y + dy
    tile_x, tile_y = new_x // TILE_SIZE, new_y // TILE_SIZE
    if 0 <= tile_y < rows and 0 <= tile_x < cols and can_move_to(lines[tile_y][tile_x]):
        player_x, player_y = new_x, new_y

# === CLASSE MENU ===
class Menu:
    def __init__(self, screen, options):
        self.screen = screen
        self.options = options
        self.font = pygame.font.Font(font_path, 50)
        self.selected_index = 0
        self.option_rects = []

    def draw(self):
        self.screen.blit(pygame.transform.scale(background_img, (WIN_WIDTH, WIN_HEIGHT)), (0, 0))
        self.option_rects = []
        for i, option in enumerate(self.options):
            font = pygame.font.Font(font_path, 50 if i != self.selected_index else 60)
            text = font.render(option, True, WHITE if i != self.selected_index else RED)
            text_rect = text.get_rect(center=(WIN_WIDTH // 2, 300 + i * 80))
            self.screen.blit(text, text_rect)
            self.option_rects.append((option, text_rect))
    
    def event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected_index = (self.selected_index - 1) % len(self.options)
            elif event.key == pygame.K_DOWN:
                self.selected_index = (self.selected_index + 1) % len(self.options)
            elif event.key == pygame.K_RETURN or event.key == pygame.K_j:
                return self.options[self.selected_index]
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = pygame.mouse.get_pos()
            for option, rect in self.option_rects:
                if rect.collidepoint(mouse_pos):
                    return option
        return None

# === AFFICHAGE DU MENU ===
def menu():
    pygame.mixer.music.load(music_path)
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play(-1, 0.0)
    
    menu = Menu(win, ["Jouer", "Quitter"])
    
    while True:
        menu.draw()
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            selected = menu.event(event)
            if selected:
                if selected == "Jouer":
                    return
                elif selected == "Quitter":
                    pygame.quit()
                    sys.exit()

# === BOUCLE PRINCIPALE ===
def game_loop():
    running = True
    clock = pygame.time.Clock()
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    menu()
                elif event.key == pygame.K_RIGHT:
                    move_player(PLAYER_SPEED_WALK, 0)
                elif event.key == pygame.K_LEFT:
                    move_player(-PLAYER_SPEED_WALK, 0)
                elif event.key == pygame.K_DOWN:
                    move_player(0, PLAYER_SPEED_WALK)
                elif event.key == pygame.K_UP:
                    move_player(0, -PLAYER_SPEED_WALK)
        
        win.fill(BLACK)
        pygame.display.flip()
        clock.tick(60)
    
    pygame.quit()

if __name__ == "__main__":
    menu()
    game_loop()
