import pygame
import csv
import os

# Constantes
WIN_WIDTH = 1920
WIN_HEIGHT = 1080
TILE_SIZE = 80  # Taille des tuiles
PLAYER_SIZE = 40  # Taille du joueur
PLAYER_COLOR = (0, 255, 0)  # Vert
PLAYER_SPEED = 10 # Vitesse de déplacement du joueur
BLACK = (0, 0, 0)  # Couleur de fond

# Initialisation de Pygame
pygame.init()
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Survivor")

# Fonction pour charger et redimensionner une image
def load_and_scale_image(path):
    try:
        return pygame.transform.scale(pygame.image.load(path).convert(), (TILE_SIZE, TILE_SIZE))
    except pygame.error as e:
        print(f"Erreur lors du chargement de l'image {path}: {e}")
        return None

# Dictionnaire pour associer chaque caractère à son image (chiffres remplacés par 0 à 42)
image_map = {
    0 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_left_exterior_corner.png'),
    1 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_right_exterior_corner.png'),
    2 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_left_interior_corner.png'),
    3 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_right_interior_corner.png'),
    4 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/right.png'),
    5 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/bottom.png'),
    6 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_left_exterior_corner.png'),
    7 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_right_exterior_corner.png'),
    8 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_left_interior_corner.png'),
    9 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_right_interior_corner.png'),
    10: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/top.png'),
    11: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/left.png'),
    12: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_left_exterior_corner.png'),
    13: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_right_exterior_corner.png'),
    14: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_left_interior_corner.png'),
    15: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_right_interior_corner.png'),
    16: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/right.png'),
    17: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/bottom.png'),
    18: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_left_exterior_corner.png'),
    19: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_right_exterior_corner.png'),
    20: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_left_interior_corner.png'),
    21: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_right_interior_corner.png'),
    22: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/top.png'),
    23: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/left.png'),
    24: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_left_wall.png'),
    25: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_top_wall.png'),
    26: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_left_corner.png'),
    27: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_right_corner.png'),
    28: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    29: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    30: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_bottom_wall.png'),
    31: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_right_wall.png'),
    32: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_left_corner.png'),
    33: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_right_corner.png'),
    34: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    35: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    36: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/path_bg_color.png'),
    37: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/exterior_background.png'),
    38: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/interior_background.png'),
    40: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_top-left_bottom-right.png'),
    41: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_bottom-left_top-right.png'),

}

# Lecture du fichier CSV pour générer la matrice
def load_matrix_from_csv(file_path):
    if not os.path.exists(file_path):
        print(f"Erreur : le fichier '{file_path}' est introuvable.")
        return []
    try:
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            return [list(row) for row in reader]
    except Exception as e:
        print(f"Erreur lors de la lecture du fichier CSV : {e}")
        return []

# Charger la matrice
matrix_file = 'nul.csv'
lines = load_matrix_from_csv(matrix_file)

if not lines:
    print("La matrice est vide ou invalide.")
    pygame.quit()
    exit()

# Dimensions de la matrice
rows = len(lines)
cols = len(lines[0])

# Dimensions de la matrice en pixels
matrix_width = cols * TILE_SIZE
matrix_height = rows * TILE_SIZE

# Position initiale du joueur dans le monde
player_world_x = matrix_width // 2
player_world_y = matrix_height // 2

# Position fixe du joueur au centre de la fenêtre
player_screen_x = WIN_WIDTH // 2
player_screen_y = WIN_HEIGHT // 2

# Fonction pour vérifier si une case est traversable
def can_move_to(tile_char):
    # Cases traversables : '8' et certaines lettres
    if tile_char == '38' or tile_char.isalpha():
        return True
    else:
        return False

# Boucle principale
running = True
clock = pygame.time.Clock()

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Gérer les touches pour le déplacement
    keys = pygame.key.get_pressed()
    move_x = 0
    move_y = 0

    if keys[pygame.K_w] or keys[pygame.K_UP]:
        move_y = -PLAYER_SPEED
    if keys[pygame.K_s] or keys[pygame.K_DOWN]:
        move_y = PLAYER_SPEED
    if keys[pygame.K_a] or keys[pygame.K_LEFT]:
        move_x = -PLAYER_SPEED
    if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
        move_x = PLAYER_SPEED

    # Calculer les nouvelles positions de la matrice en fonction du mouvement
    new_player_row = (player_world_y + move_y) // TILE_SIZE
    new_player_col = (player_world_x + move_x) // TILE_SIZE

    # Vérification des collisions
    if 0 <= new_player_row < rows and can_move_to(lines[new_player_row][player_world_x // TILE_SIZE]):
        player_world_y += move_y  # Mouvement vertical autorisé si la case est traversable
    if 0 <= new_player_col < cols and can_move_to(lines[player_world_y // TILE_SIZE][new_player_col]):
        player_world_x += move_x  # Mouvement horizontal autorisé si la case est traversable

    # Calculer les décalages de la caméra
    camera_offset_x = player_world_x - player_screen_x
    camera_offset_y = player_world_y - player_screen_y

    # Remplir l'écran de noir pour le rafraîchissement
    win.fill(BLACK)

    # Afficher les images selon la matrice en fonction du décalage de la caméra
    for row_index, line in enumerate(lines):
        for col_index, char in enumerate(line):
            char = int(char) if char.isdigit() else char
            image = image_map.get(char)
            if image:
                x = col_index * TILE_SIZE - camera_offset_x
                y = row_index * TILE_SIZE - camera_offset_y
                if 0 <= x < WIN_WIDTH and 0 <= y < WIN_HEIGHT :
                    win.blit(image, (x, y))

    # Dessiner le joueur au centre de l'écran
    pygame.draw.rect(win, PLAYER_COLOR, (player_screen_x - PLAYER_SIZE // 2, player_screen_y - PLAYER_SIZE // 2, PLAYER_SIZE, PLAYER_SIZE))

    # Mettre à jour l'affichage
    pygame.display.flip()
    clock.tick(60)

# Quitter Pygame
pygame.quit()
