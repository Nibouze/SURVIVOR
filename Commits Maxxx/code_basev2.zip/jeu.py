#==================================================
#--------------------IMPORTATIONS------------------
#==================================================



import pygame
import csv
import os
import random

#==================================================
#--------------------CONSTANTES--------------------
#==================================================


WIN_WIDTH = 1920
WIN_HEIGHT = 1080
TILE_SIZE = 80  
PLAYER_SCALE = 2  
PLAYER_SPEED_WALK = 5  
PLAYER_SPEED_RUN = 10  
BLACK = (0, 0, 0)  



#==================================================
#----------------PYGAME INITIALISATION-------------
#==================================================


if not pygame.get_init():
    pygame.init()
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Survivor")



#==================================================
#----------------CLASS DU JEU----------------------
#==================================================


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.run_spritesheet = pygame.image.load('sprites/player/run.png')  
        self.walk_spritesheet = pygame.image.load('sprites/player/walk.png') 
        self.attaque_3_spritesheet = pygame.image.load('sprites/player/attaque3.png') 
        self.mort = pygame.image.load('sprites/player/hurt.png')
        self.wait = pygame.image.load('sprites/player/waiting.png')
        self.frame_width = self.run_spritesheet.get_width() // 8  
        self.frame_height = self.run_spritesheet.get_height() // 4  
        self.scale_factor = PLAYER_SCALE        
        self.current_sprite = 0
        self.moving = False
        self.running = False
        self.attacking = False
        self.attack_type = None
        self.direction = "down"
        self.rect = pygame.Rect(pos_x, pos_y, self.frame_width * self.scale_factor, self.frame_height * self.scale_factor)

    def get_frame(self, frame, direction, running, attacking=False):
        directions = {"up": 0, "left": 1, "down": 2, "right": 3}  
        row = directions.get(direction, 2)  
        x = int(frame) * self.frame_width  
        y = row * self.frame_height

        # Initialisation de spritesheet à None pour éviter l'erreur
        spritesheet = None  

        if attacking:
            if self.attack_type == 3:
                spritesheet = self.attaque_3_spritesheet
            else:
                return None  # Si une autre attaque est ajoutée plus tard, éviter une erreur
        else:
            spritesheet = self.run_spritesheet if running else self.walk_spritesheet
        
        # Vérification si la spritesheet a bien été assignée
        if spritesheet is None:
            print("Erreur : spritesheet non chargée ou non définie !")
            return None  # Évite de planter le jeu

        frame_image = spritesheet.subsurface(pygame.Rect(x, y, self.frame_width, self.frame_height))
        return pygame.transform.scale(frame_image, (self.frame_width * self.scale_factor, self.frame_height * self.scale_factor))


    def get_attack_frames(self):
        if self.attack_type == 3:
            return 8  # Nombre de frames pour l'attaque
        return 8  # Par défaut


    def start_moving(self, direction, running):
        if not self.attacking:
            self.moving = True
            self.running = running
            self.direction = direction

    def stop_moving(self):
        if not self.attacking:
            self.moving = False
            self.current_sprite = 0

    def start_attack(self, attack_type):
        self.attacking = True
        self.attack_type = attack_type
        self.current_sprite = 0

    def update(self):
        if self.attacking:
            self.current_sprite += 0.2  
            if self.current_sprite >= self.get_attack_frames():  
                self.attacking = False
                self.current_sprite = 0

        elif self.moving:
            self.current_sprite += 0.2  
            if self.current_sprite >= 8:
                self.current_sprite = 0

        new_image = self.get_frame(int(self.current_sprite), self.direction, self.running, self.attacking)
        
        if new_image:
            self.image = new_image
            self.rect.width = self.image.get_width()  # Adapter la taille du rect au sprite actuel
            self.rect.height = self.image.get_height()
        else:
            self.image = self.get_frame(0, self.direction, False)


class Orc(Player):
    def __init__(self, pos_x, pos_y):
        super().__init__(pos_x, pos_y)
        self.run_spritesheet = pygame.image.load('sprites/player/orc_run.png')
        self.frame_width = self.run_spritesheet.get_width() // 8  # Diviser par 8 colonnes
        self.frame_height = self.run_spritesheet.get_height() // 4  # Diviser par 4 lignes

        self.direction = random.choice(["up", "down", "left", "right"])
        self.speed = 5
        self.move_timer = random.randint(30, 90)  # Temps avant de changer de direction

    def update(self):
        self.move_timer -= 1
        if self.move_timer <= 0:    # Déterminer la direction vers le joueur
            diff_x = player.rect.x - self.rect.x
            diff_y = player.rect.y - self.rect.y
            # Priorité : déplacement horizontal ou vertical en fonction de la distance la plus grande
            if abs(diff_x) > abs(diff_y):
                if diff_x > 0:
                    new_direction = "right"
                else:
                    new_direction = "left"
            else:
                if diff_y > 0:
                    new_direction = "down"
                else:
                    new_direction = "up"

            # Vérifier que la prochaine case est bien une case "38"
            center_x = self.rect.centerx + (self.speed if new_direction == "right" else -self.speed if new_direction == "left" else 0)
            center_y = self.rect.centery + (self.speed if new_direction == "down" else -self.speed if new_direction == "up" else 0)
            new_row = center_y // TILE_SIZE
            new_col = center_x // TILE_SIZE
            if 0 <= new_row < rows and 0 <= new_col < cols and lines[new_row][new_col] == '38':
                self.direction = new_direction  # Appliquer la nouvelle direction
            self.move_timer = random.randint(30, 90)  # Reset du timer de déplacement


        # Calcul du déplacement basé sur la direction actuelle
        move_x, move_y = 0, 0
        if self.direction == "up":
            move_y = -self.speed
        elif self.direction == "down":
            move_y = self.speed
        elif self.direction == "left":
            move_x = -self.speed
        elif self.direction == "right":
            move_x = self.speed

        # Vérification des cases "38" avant déplacement
        center_x = self.rect.centerx + move_x
        center_y = self.rect.centery + move_y
        new_row = center_y // TILE_SIZE
        new_col = center_x // TILE_SIZE

        if 0 <= new_row < rows and lines[new_row][self.rect.x // TILE_SIZE] in map(str, range(25, 39)):
            self.rect.y += move_y  
        if 0 <= new_col < cols and lines[self.rect.y // TILE_SIZE][new_col] in map(str, range(25, 39)):
            self.rect.x += move_x  
        self.current_sprite += 0.2  
        if self.current_sprite >= 8:
            self.current_sprite = 0  
        self.image = self.get_frame(int(self.current_sprite), self.direction, running=True)

#==================================================
#--------------------FONCTIONS---------------------
#==================================================



def fade_in(surface, duration=60):
    """ Effet de fade-in sur la surface de jeu """
    fade_surface = pygame.Surface((WIN_WIDTH, WIN_HEIGHT))
    fade_surface.fill((0, 0, 0))
    
    for alpha in range(255, -1, -5):  # Diminue l'opacité progressivement
        fade_surface.set_alpha(alpha)
        surface.fill((0, 0, 0))  # Assurer un fond noir avant de dessiner le jeu
        surface.blit(fade_surface, (0, 0))
        pygame.display.flip()
        pygame.time.delay(duration // 30)  # Ajuste la vitesse du fade-in



def load_and_scale_image(path):
    """Chargemeent et decoupage des image importées"""
    try:
        return pygame.transform.scale(pygame.image.load(path).convert(), (TILE_SIZE, TILE_SIZE))
    except pygame.error as e:
        print(f"Error loading image {path}: {e}")
        return None

#  Dictionnaire pour associer chaque caractère à son image (chiffres remplacés par 0 à 42)
image_map = {
    0 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_left_exterior_corner.png'),
    1 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_right_exterior_corner.png'),
    2 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_left_interior_corner.png'),
    3 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_right_interior_corner.png'),
    4 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/right.png'),
    5 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/bottom.png'),
    6 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_left_exterior_corner.png'),
    7 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_right_exterior_corner.png'),
    8 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_left_interior_corner.png'),
    9 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_right_interior_corner.png'),
    10: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/top.png'),
    11: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/left.png'),
    12: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_left_exterior_corner.png'),
    13: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_right_exterior_corner.png'),
    14: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_left_interior_corner.png'),
    15: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_right_interior_corner.png'),
    16: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/right.png'),
    17: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/bottom.png'),
    18: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_left_exterior_corner.png'),
    19: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_right_exterior_corner.png'),
    20: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_left_interior_corner.png'),
    21: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_right_interior_corner.png'),
    22: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/top.png'),
    23: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/left.png'),
    24: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_left_wall.png'),
    25: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_top_wall.png'),
    26: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_left_corner.png'),
    27: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_right_corner.png'),
    28: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_top_left_corner.png'),
    29: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_top_right_corner.png'),
    30: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_bottom_wall.png'),
    31: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_right_wall.png'),
    32: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_left_corner.png'),
    33: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_right_corner.png'),
    34: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    35: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    36: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/path_bg_color.png'),
    37: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/exterior_background.png'),
    38: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/interior_background.png'),
    40: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_top-left_bottom-right.png'),
    41: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_bottom-left_top-right.png'),

}





# Load CSV map
def load_matrix_from_csv(file_path):
    """Chargement et importation des differentes map du jeu a partir de fichier csv, generer grace au dictionnaire"""
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return []
    try:
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            return [list(row) for row in reader]
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return []
matrix_file = 'nul.csv'
lines = load_matrix_from_csv(matrix_file)

# Map dimensions
rows = len(lines)
cols = len(lines[0])
matrix_width = cols * TILE_SIZE
matrix_height = rows * TILE_SIZE



# Player spawn position
player = Player(matrix_width // 2, matrix_height // 2)
# Générer 5 orcs à des positions aléatoires sur des cases "38"
orcs = []
for _ in range(5):
    while True:
        spawn_x = random.randint(0, cols - 1) * TILE_SIZE
        spawn_y = random.randint(0, rows - 1) * TILE_SIZE
        
        # Vérifier que l'Orc spawn sur une case "38"
        if lines[spawn_y // TILE_SIZE][spawn_x // TILE_SIZE] == '38':
            orcs.append(Orc(spawn_x, spawn_y))
            break  # Sortir de la boucle quand une position valide est trouvée

player_screen_x = WIN_WIDTH // 2
player_screen_y = WIN_HEIGHT // 2


def can_move_to(tile_char):
    """ Check si le mouvement est possible """
    return tile_char == '38' or tile_char.isalpha() or (tile_char.isdigit() and 25 <= int(tile_char) <= 38)


running = True
clock = pygame.time.Clock()

def main():
    running = True
    clock = pygame.time.Clock()

    win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT), pygame.RESIZABLE)

    # Création d'une surface noire pour le fade-in
    fade_surface = pygame.Surface((WIN_WIDTH, WIN_HEIGHT))
    fade_surface.fill((0, 0, 0))
    fade_alpha = 255  # Opacité initiale (complètement noir)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYUP:
                if event.key in [pygame.K_RIGHT, pygame.K_LEFT, pygame.K_UP, pygame.K_DOWN, pygame.K_d, pygame.K_a, pygame.K_w, pygame.K_s]:
                    player.stop_moving()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    player.start_attack(3)

        keys = pygame.key.get_pressed()

        move_x, move_y = 0, 0
        speed = PLAYER_SPEED_RUN if keys[pygame.K_w] or keys[pygame.K_a] or keys[pygame.K_s] or keys[pygame.K_d] else PLAYER_SPEED_WALK

        if not player.attacking:
            if keys[pygame.K_w]:  
                player.start_moving("up", running=True)
                move_y = -speed
            elif keys[pygame.K_UP]:  
                player.start_moving("up", running=False)
                move_y = -speed

            if keys[pygame.K_s]:  
                player.start_moving("down", running=True)
                move_y = speed
            elif keys[pygame.K_DOWN]:  
                player.start_moving("down", running=False)
                move_y = speed

            if keys[pygame.K_a]:  
                player.start_moving("left", running=True)
                move_x = -speed
            elif keys[pygame.K_LEFT]:  
                player.start_moving("left", running=False)
                move_x = -speed

            if keys[pygame.K_d]:  
                player.start_moving("right", running=True)
                move_x = speed
            elif keys[pygame.K_RIGHT]:  
                player.start_moving("right", running=False)
                move_x = speed

        new_row = (player.rect.y + move_y + 10) // TILE_SIZE
        new_col = (player.rect.x + move_x) // TILE_SIZE

        if 0 <= new_row < rows and can_move_to(lines[new_row][player.rect.x // TILE_SIZE]):
            player.rect.y += move_y  
        if 0 <= new_col < cols and can_move_to(lines[player.rect.y // TILE_SIZE][new_col]):
            player.rect.x += move_x  

        camera_offset_x = player.rect.x - player_screen_x
        camera_offset_y = player.rect.y - player_screen_y

        win.fill(BLACK)

        for row_index, line in enumerate(lines):
            for col_index, char in enumerate(line):
                char = int(char) if char.isdigit() else char
                image = image_map.get(char)
                if image:
                    x = col_index * TILE_SIZE - camera_offset_x
                    y = row_index * TILE_SIZE - camera_offset_y
                    if 0 <= x < WIN_WIDTH and 0 <= y < WIN_HEIGHT :
                        win.blit(image, (x, y))
        player.update()
        win.blit(player.image, (player_screen_x - player.rect.width // 2, player_screen_y - player.rect.height // 2))
        # Mettre à jour et afficher tous les Orcs
        for orc in orcs:
            orc.update()
            win.blit(orc.image, (orc.rect.x - camera_offset_x, orc.rect.y - camera_offset_y))



        # Effet de fade-in pendant la boucle principale
        if fade_alpha > 0:
            fade_surface.set_alpha(fade_alpha)
            win.blit(fade_surface, (0, 0))
            fade_alpha -= 5  # Réduction progressive de l'opacité

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()



if __name__ == "__main__":
    main()