import pygame
import csv
import os

# Constants
WIN_WIDTH = 1920
WIN_HEIGHT = 1080
TILE_SIZE = 80  
PLAYER_SCALE = 2  
PLAYER_SPEED_WALK = 5  
PLAYER_SPEED_RUN = 10  
BLACK = (0, 0, 0)  

# Pygame Initialization
pygame.init()
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Survivor")

# Function to load and scale images
def load_and_scale_image(path):
    try:
        return pygame.transform.scale(pygame.image.load(path).convert(), (TILE_SIZE, TILE_SIZE))
    except pygame.error as e:
        print(f"Error loading image {path}: {e}")
        return None

#  Dictionnaire pour associer chaque caractère à son image (chiffres remplacés par 0 à 42)
image_map = {
    0 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_left_exterior_corner.png'),
    1 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/top_right_exterior_corner.png'),
    2 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_left_interior_corner.png'),
    3 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/top_right_interior_corner.png'),
    4 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/right.png'),
    5 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/bottom.png'),
    6 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_left_exterior_corner.png'),
    7 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners/bottom_right_exterior_corner.png'),
    8 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_left_interior_corner.png'),
    9 : load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners/bottom_right_interior_corner.png'),
    10: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/top.png'),
    11: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls/left.png'),
    12: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_left_exterior_corner.png'),
    13: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/top_right_exterior_corner.png'),
    14: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_left_interior_corner.png'),
    15: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/top_right_interior_corner.png'),
    16: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/right.png'),
    17: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/bottom.png'),
    18: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_left_exterior_corner.png'),
    19: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Exterior_Corners_v2/bottom_right_exterior_corner.png'),
    20: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_left_interior_corner.png'),
    21: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Interior_Corners_v2/bottom_right_interior_corner.png'),
    22: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/top.png'),
    23: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Walls_v2/left.png'),
    24: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_left_wall.png'),
    25: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_top_wall.png'),
    26: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_left_corner.png'),
    27: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_top_right_corner.png'),
    28: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    29: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    30: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_bottom_wall.png'),
    31: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_walls/path_right_wall.png'),
    32: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_left_corner.png'),
    33: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_interior_corners/path_bottom_right_corner.png'),
    34: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_left_corner.png'),
    35: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/path_exteriors_corners/path_bottom_right_corner.png'),
    36: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/path_bg_color.png'),
    37: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/exterior_background.png'),
    38: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/Backgrounds/interior_background.png'),
    40: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_top-left_bottom-right.png'),
    41: load_and_scale_image('images/cornes_tiles_x80/Tileset/Exports/diagonals/diagonal_bottom-left_top-right.png'),

}

# Load CSV map
def load_matrix_from_csv(file_path):
    if not os.path.exists(file_path):
        print(f"Error: File '{file_path}' not found.")
        return []
    try:
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            return [list(row) for row in reader]
    except Exception as e:
        print(f"Error reading CSV file: {e}")
        return []

matrix_file = 'nul.csv'
lines = load_matrix_from_csv(matrix_file)

if not lines:
    print("Error: Empty or invalid matrix.")
    pygame.quit()
    exit()

# Map dimensions
rows = len(lines)
cols = len(lines[0])
matrix_width = cols * TILE_SIZE
matrix_height = rows * TILE_SIZE

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__()
        self.run_spritesheet = pygame.image.load('sprites/player/run.png')  
        self.walk_spritesheet = pygame.image.load('sprites/player/walk.png') 
        self.attaque_1_spritesheet = pygame.image.load('sprites/player/attaque1.png') 
        self.attaque_2_spritesheet = pygame.image.load('sprites/player/attaque2.png') 
        self.attaque_3_spritesheet = pygame.image.load('sprites/player/attaque3.png') 

        self.frame_width = self.run_spritesheet.get_width() // 8  
        self.frame_height = self.run_spritesheet.get_height() // 4  

        self.scale_factor = PLAYER_SCALE  
        
        self.current_sprite = 0
        self.moving = False
        self.running = False
        self.attacking = False
        self.attack_type = None
        self.direction = "down"
        self.rect = pygame.Rect(pos_x, pos_y, self.frame_width * self.scale_factor, self.frame_height * self.scale_factor)

    def get_frame(self, frame, direction, running, attacking=False):
        directions = {"up": 0, "left": 1, "down": 2, "right": 3}  
        row = directions.get(direction, 2)  
        x = frame * self.frame_width
        y = row * self.frame_height

        if attacking:
            if self.attack_type == 1:
                spritesheet = self.attaque_1_spritesheet
            elif self.attack_type == 2:
                spritesheet = self.attaque_2_spritesheet
            elif self.attack_type == 3:
                spritesheet = self.attaque_3_spritesheet
            else:
                return None  
        else:
            spritesheet = self.run_spritesheet if running else self.walk_spritesheet
        
        frame_image = spritesheet.subsurface(pygame.Rect(x, y, self.frame_width, self.frame_height))
        return pygame.transform.scale(frame_image, (self.frame_width * self.scale_factor, self.frame_height * self.scale_factor))

    def get_attack_frames(self):
        if self.attack_type == 1:
            return 6
        elif self.attack_type == 2:
            return 6
        elif self.attack_type == 3:
            return 8
        return 8  # Valeur par défaut


    def start_moving(self, direction, running):
        if not self.attacking:
            self.moving = True
            self.running = running
            self.direction = direction

    def stop_moving(self):
        if not self.attacking:
            self.moving = False
            self.current_sprite = 0

    def start_attack(self, attack_type):
        self.attacking = True
        self.attack_type = attack_type
        self.current_sprite = 0

    def update(self):
        if self.attacking:
            self.current_sprite += 0.2  
            if self.current_sprite >= self.get_attack_frames():  # On utilise le bon nombre de frames
                self.attacking = False
                self.current_sprite = 0
        elif self.moving:
            self.current_sprite += 0.2  
            if self.current_sprite >= 8:
                self.current_sprite = 0

        # Récupérer l'image actuelle
        new_image = self.get_frame(int(self.current_sprite), self.direction, self.running, self.attacking)
        
        # S'assurer que l'image n'est jamais None
        if new_image:
            self.image = new_image
        else:
            self.image = self.get_frame(0, self.direction, False)  # Remet un sprite de base si erreur


# Player spawn position
player = Player(matrix_width // 2, matrix_height // 2)
player_screen_x = WIN_WIDTH // 2
player_screen_y = WIN_HEIGHT // 2

# Check if movement is possible
def can_move_to(tile_char):
    return tile_char == '38' or tile_char.isalpha()  

running = True
clock = pygame.time.Clock()

def main():
    running = True
    clock = pygame.time.Clock()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYUP:
                if event.key in [pygame.K_RIGHT, pygame.K_LEFT, pygame.K_UP, pygame.K_DOWN, pygame.K_d, pygame.K_a, pygame.K_w, pygame.K_s]:
                    player.stop_moving()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    player.start_attack(1)
                elif event.key == pygame.K_2:
                    player.start_attack(2)
                elif event.key == pygame.K_3:
                    player.start_attack(3)

        keys = pygame.key.get_pressed()
        move_x, move_y = 0, 0
        speed = PLAYER_SPEED_RUN if keys[pygame.K_w] or keys[pygame.K_a] or keys[pygame.K_s] or keys[pygame.K_d] else PLAYER_SPEED_WALK

        if not player.attacking:
            if keys[pygame.K_w]:  
                player.start_moving("up", running=True)
                move_y = -speed
            elif keys[pygame.K_UP]:  
                player.start_moving("up", running=False)
                move_y = -speed

            if keys[pygame.K_s]:  
                player.start_moving("down", running=True)
                move_y = speed
            elif keys[pygame.K_DOWN]:  
                player.start_moving("down", running=False)
                move_y = speed

            if keys[pygame.K_a]:  
                player.start_moving("left", running=True)
                move_x = -speed
            elif keys[pygame.K_LEFT]:  
                player.start_moving("left", running=False)
                move_x = -speed

            if keys[pygame.K_d]:  
                player.start_moving("right", running=True)
                move_x = speed
            elif keys[pygame.K_RIGHT]:  
                player.start_moving("right", running=False)
                move_x = speed

        new_row = (player.rect.y + move_y + 10) // TILE_SIZE
        new_col = (player.rect.x + move_x) // TILE_SIZE

        if 0 <= new_row < rows and can_move_to(lines[new_row][player.rect.x // TILE_SIZE]):
            player.rect.y += move_y  
        if 0 <= new_col < cols and can_move_to(lines[player.rect.y // TILE_SIZE][new_col]):
            player.rect.x += move_x  

        camera_offset_x = player.rect.x - player_screen_x
        camera_offset_y = player.rect.y - player_screen_y

        win.fill(BLACK)

        for row_index, line in enumerate(lines):
            for col_index, char in enumerate(line):
                char = int(char) if char.isdigit() else char
                image = image_map.get(char)
                if image:
                    x = col_index * TILE_SIZE - camera_offset_x
                    y = row_index * TILE_SIZE - camera_offset_y
                    if 0 <= x < WIN_WIDTH and 0 <= y < WIN_HEIGHT:
                        win.blit(image, (x, y))

        player.update()
        win.blit(player.image, (player_screen_x - player.rect.width // 2, player_screen_y - player.rect.height // 2))

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()



if __name__ == "__main__":
    main()

