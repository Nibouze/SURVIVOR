import pygame
import os

# Constants
WIN_WIDTH = 1920
WIN_HEIGHT = 1080
TILE_SIZE = 80  
PLAYER_SCALE = 2  
PLAYER_SPEED_WALK = 5  
PLAYER_SPEED_RUN = 10  
BLACK = (0, 0, 0)  

# Pygame Initialization
pygame.init()
win = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
pygame.display.set_caption("Survivor Animation")
clock = pygame.time.Clock()

# Load images

def load_sprite_sheet(filename, frame_count, scale):
    sprite_sheet = pygame.image.load(filename).convert_alpha()
    sheet_width, sheet_height = sprite_sheet.get_size()
    frame_width = sheet_width // frame_count
    frames = [
        pygame.transform.scale(sprite_sheet.subsurface((i * frame_width, 0, frame_width, sheet_height)),
                               (frame_width * scale, sheet_height * scale))
        for i in range(frame_count)
    ]
    return frames

# Load animations
animations = {
    "walk": load_sprite_sheet("sprites/player/walk.png", 8, PLAYER_SCALE),
    "run": load_sprite_sheet("sprites/player/run.png", 8, PLAYER_SCALE),
    "attack1": load_sprite_sheet("sprites/player/attaque1.png", 6, PLAYER_SCALE),
    "attack2": load_sprite_sheet("sprites/player/attaque2.png", 6, PLAYER_SCALE),
    "attack3": load_sprite_sheet("sprites/player/attaque3.png", 8, PLAYER_SCALE),
}

# Player class
class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.vel_x = 0
        self.vel_y = 0
        self.speed = PLAYER_SPEED_WALK
        self.running = False
        self.attacking = False
        self.attack_type = None
        self.current_frame = 0
        self.image = animations["walk"][0]
        self.rect = self.image.get_rect(topleft=(x, y))

    def move(self, direction, running):
        if not self.attacking:
            self.running = running
            if direction == "left":
                self.vel_x = -self.speed
            elif direction == "right":
                self.vel_x = self.speed
            elif direction == "up":
                self.vel_y = -self.speed
            elif direction == "down":
                self.vel_y = self.speed

    def stop(self):
        self.vel_x = 0
        self.vel_y = 0

    def attack(self, attack_type):
        self.attacking = True
        self.attack_type = attack_type
        self.current_frame = 0

    def update(self):
        if self.attacking:
            anim_key = f"attack{self.attack_type}"
            self.current_frame += 0.2
            if self.current_frame >= len(animations[anim_key]):
                self.attacking = False
                self.current_frame = 0
            self.image = animations[anim_key][int(self.current_frame)]
        else:
            anim_key = "run" if self.running else "walk"
            self.current_frame += 0.2
            if self.current_frame >= len(animations[anim_key]):
                self.current_frame = 0
            self.image = animations[anim_key][int(self.current_frame)]

        self.x += self.vel_x
        self.y += self.vel_y
        self.rect.topleft = (self.x, self.y)

# Initialize player
player = Player(WIN_WIDTH // 2, WIN_HEIGHT // 2)

running = True
while running:
    win.fill(BLACK)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_1:
                player.attack(1)
            elif event.key == pygame.K_2:
                player.attack(2)
            elif event.key == pygame.K_3:
                player.attack(3)

    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        player.move("left", keys[pygame.K_LSHIFT])
    elif keys[pygame.K_RIGHT]:
        player.move("right", keys[pygame.K_LSHIFT])
    elif keys[pygame.K_UP]:
        player.move("up", keys[pygame.K_LSHIFT])
    elif keys[pygame.K_DOWN]:
        player.move("down", keys[pygame.K_LSHIFT])
    else:
        player.stop()

    player.update()
    win.blit(player.image, (player.x, player.y))
    pygame.display.flip()
    clock.tick(60)

pygame.quit()
