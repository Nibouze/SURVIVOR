<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tileset" tilewidth="40" tileheight="40" tilecount="42" columns="6">
 <image source="tileset.png" width="240" height="280"/>
</tileset>
